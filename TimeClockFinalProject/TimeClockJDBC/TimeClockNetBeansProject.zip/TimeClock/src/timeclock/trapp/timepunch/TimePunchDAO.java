package timeclock.trapp.timepunch;

import java.util.ArrayList;
import timeclock.trapp.data.DatabaseConnectionFactory;
import timeclock.trapp.data.DatabaseType;
import timeclock.trapp.employee.Employee;
import java.util.Date;
import java.sql.SQLException;

/**
 * The TimePunch Data Access Object handles persistent storage of data related
 * to TimePunch objects.
 * @author Bob
 */
public class TimePunchDAO {

    /**
     * The URL for the database holding the Employee data.
     */
    private String dbUrl;
    
    /**
     * The name of the database holding the Employee data.
     */
    private String dbName;
    
    /**
     * The database user name to use when connecting to the database.
     */
    private String dbUserName;
    
    /**
     * The password for the database user.
     */
    private String dbUserPassword;
    
    /**
     * Records a time punch with the specified employeeId and source, using the
     * current time.
     * 
     * @param employeeId 
     * @param source 
     * @throws java.sql.SQLException 
     */
    public void recordTimePunch(String employeeId, String source)
                                throws SQLException  {
        
    }
    
    /**
     * Records a time punch with the specified Employee and source, using the
     * current time.
     * 
     * @param employee
     * @param source 
     * @throws java.sql.SQLException 
     */
    public void recordTimePunch(Employee employee, String source) 
                                throws SQLException {
        
    }
    
    /**
     * Marks a time punch record as invalid.
     * 
     * @param employeeId
     * @param punchTime 
     * @param invalidatedBy 
     * @param invalidatedReason 
     * @throws java.sql.SQLException 
     */
    public void invalidateTimePunch(String employeeId
                                , Date punchTime
                                , String invalidatedBy
                                , String invalidatedReason)
                                throws SQLException {
        
    }
    
    /**
     * Returns a list of the time punch records between start and end dates.
     * 
     * @param startDate
     * @param endDate
     * @return
     * @throws SQLException
     */
    public ArrayList<TimePunch> getTimePunchsByDateRange(Date startDate
                                    , Date endDate) throws SQLException {
        return null;
    }
    
    /**
     * Returns a list of the time punch records between start and end dates.
     * 
     * @param startDate
     * @param endDate
     * @return
     * @throws SQLException
     */
    public ArrayList<TimePunch> getTimePunchsByDateRange(String startDate
                                    , String endDate) throws SQLException {
        return null;
    }
    
    /**
     * Returns a list of the time punch records between start and end dates 
     * for the specified employee.
     * 
     * @param employee
     * @param startDate
     * @param endDate
     * @return
     * @throws SQLException
     */
    public ArrayList<TimePunch> getTimePunchsByEmployeeDateRange(
                                    Employee employee
                                    , Date startDate
                                    , Date endDate) throws SQLException {
        return null;
    }
    
    /**
     * Returns a list of the time punch records between start and end dates
     * for the specified employee ID.
     * 
     * @param employeeId
     * @param startDate
     * @param endDate
     * @return
     * @throws SQLException
     */
    public ArrayList<TimePunch> getTimePunchsByEmployeeDateRange(
                                    String employeeId
                                    , String startDate
                                    , String endDate) throws SQLException {
        return null;
    }

    /**
     * The URL for the database holding the Employee data.
     * @return the dbUrl
     */
    public String getDbUrl() {
        return dbUrl;
    }

    /**
     * The URL for the database holding the Employee data.
     * @param dbUrl the dbUrl to set
     */
    public void setDbUrl(String dbUrl) {
        this.dbUrl = dbUrl;
    }

    /**
     * The name of the database holding the Employee data.
     * @return the dbName
     */
    public String getDbName() {
        return dbName;
    }

    /**
     * The name of the database holding the Employee data.
     * @param dbName the dbName to set
     */
    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    /**
     * The database user name to use when connecting to the database.
     * @return the dbUserName
     */
    public String getDbUserName() {
        return dbUserName;
    }

    /**
     * The database user name to use when connecting to the database.
     * @param dbUserName the dbUserName to set
     */
    public void setDbUserName(String dbUserName) {
        this.dbUserName = dbUserName;
    }

    /**
     * The password for the database user.
     * @return the dbUserPassword
     */
    public String getDbUserPassword() {
        return dbUserPassword;
    }

    /**
     * The password for the database user.
     * @param dbUserPassword the dbUserPassword to set
     */
    public void setDbUserPassword(String dbUserPassword) {
        this.dbUserPassword = dbUserPassword;
    }
    
}
