package timeclock.trapp.data;

/**
 * An enumeration listing the various types of databases known to this software.
 * @author Bob
 */
public enum DatabaseType {
    MSSQL, MYSQL;
}
